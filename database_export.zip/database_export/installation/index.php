<?php
if(isset($_POST['install'])){
    if(!empty($_POST['install'])){
        if(empty($_POST['password'])){
            $db_password = '';
        } else {
            $db_password = $_POST['passowrd'];
        }
        if(empty($_POST['wp_password'])){
            $wp_db_password = '';
         } else {
             $wp_db_password = $_POST['wp_passowrd'];
         }
        $conn = mysqli_connect($_POST['host'], $_POST['username'], $_POST['password'], $_POST['db_name']);
        if(!$conn){
            echo "Error: " . mysqli_error($conn);
        } else {
            $table = 'CREATE TABLE db_post (
                id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
                post_id INT(11) NOT NULL,
                db_title VARCHAR(255) NOT NULL,
                db_image VARCHAR(255),
                db_content TEXT NOT NULL
                )';
            $run = mysqli_query($conn, $table); 
            if($run){
                echo "Successfully Created Table";
            }   else {
                echo "Error: " . mysqli_error($conn);
            }

            $file_content =
            '<?php
// +------------------------------------------------------------------------+
// | @author Anwar Ali (Freelancer)
// | @author_url 1: http://freelancer.com/anwarsolangi
// | @author_url 2: http://facebook.com/anwerxolangi
// | @author_email: anwersolangi@gmail.com
// +------------------------------------------------------------------------+
// | Wordpress Plugins By Anwar Ali
// | Copyright (c) Anwar Ali.
// +------------------------------------------------------------------------+
// MySQL Hostname
$db_host = "'  . $_POST['host'] . '";
// MySQL Database User
$db_user = "'  . $_POST['username'] . '";
// MySQL Database Password
$db_password = "'  . $db_password . '";
// MySQL Database Name
$db_name = "'  . $_POST['db_name'] . '";

$wp_db_host = "' . $_POST['wp_host'] . '";
$wp_db_user = "' . $_POST['wp_username'] . '";
$wp_db_pass = "' . $wp_db_password . '";
$wp_db_name = "' . $_POST['wp_db_name'] . '";

$conn = mysqli_connect($db_host,$db_user,$db_password,$db_name);

$conn2 = mysqli_connect($wp_db_host, $wp_db_user, $wp_pass, $wp_db_name);

?>';
$filename = "../config.php";

file_put_contents($filename, $file_content);

        } 
    }
}



?>
<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Install Plugin</title>
  <meta name="viewport" content="width=device-width, initial-scale=1"><link href='https://fonts.googleapis.com/css?family=Roboto:400,700' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">

  
      <link rel="stylesheet" href="css/style.css">

  
</head>

<body>

  <div class="user">
    <header class="user__header">
        <img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/3219/logo.svg" alt="" />
        <h1 class="user__title">Install Plugin By Anwar Ali (NOTE: Provide Correct Details Otherwise Plugin Will Not Work Correctly)</h1>
    </header>
    
    <form class="form" method="post" id="form_install">
        <div class="form__group">
            <input type="text" name="host" placeholder="SQL Host" class="form__input" />
        </div>
        
        <div class="form__group">
            <input type="text" placeholder="SQL Username" name="username" class="form__input" />
        </div>
        
        <div class="form__group">
            <input type="password" name="password" placeholder="Password" class="form__input" />
        </div>
        <div class="form__group">
            <input type="text" placeholder="Database Name" name="db_name" class="form__input" />
        </div>

Wordpress Database(Enter Detail Of Your Wordpress Database)

        <div class="form__group">
            <input type="text" name="wp_host" placeholder="SQL Host" class="form__input" />
        </div>
        
        <div class="form__group">
            <input type="text" placeholder="SQL Username" name="wp_username" class="form__input" />
        </div>
        
        <div class="form__group">
            <input type="password" name="wp_password" placeholder="Password" class="form__input" />
        </div>
        <div class="form__group">
            <input type="text" placeholder="Database Name" name="wp_db_name" class="form__input" />
        </div>
        <input type="submit" value="Submit" name="install" class="btn">
    </form>
</div>
  
  

    <script  src="js/index.js"></script>




</body>

</html>
